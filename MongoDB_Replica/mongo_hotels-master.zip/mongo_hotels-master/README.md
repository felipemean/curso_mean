# mongo_hotels
MongoDB DDBB hoteles Node
