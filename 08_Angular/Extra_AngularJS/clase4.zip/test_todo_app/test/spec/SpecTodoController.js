'use strict';

describe("Tareas a aprender", function() {
    
  
  beforeEach( function() {
        // do nothing in this example
  });
    
  // Another way: This makes unnecesary creating the $scope using $rootScope for each test
  //beforeEach(module('app_name'));
    
    
  // Another way: This makes unnecessary the $controller injection in each test
  /*
  beforeEach(inject(function(_$controller_){
    // The injector unwraps the underscores (_) from around the parameter names when matching
    $controller = _$controller_;
  }));
  */
    

  // We can also move the var scope and var ctrl outside the 'it' blocks into 'describe' block
  it('initial item number should be 2', inject(function($rootScope, $controller) {
        var scope = $rootScope.$new();
        var ctrl = $controller('TodoCtrl', {$scope: scope});
        expect(scope.todos.length).toEqual(2);
   }));

  it('adding a item should increase the total numbers to 3', inject(function($rootScope, $controller) {
        var scope = $rootScope.$new();
        var ctrl = $controller('TodoCtrl', {$scope: scope});
        scope.addTodo();
        expect(scope.todos.length).toEqual(3);
  }));

});